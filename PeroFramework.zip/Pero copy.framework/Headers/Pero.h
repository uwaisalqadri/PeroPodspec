//
//  Pero.h
//  Pero
//
//  Created by Uwais Alqadri on 30/3/24.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCrypto.h>

//! Project version number for Pero.
FOUNDATION_EXPORT double PeroVersionNumber;

//! Project version string for Pero.
FOUNDATION_EXPORT const unsigned char PeroVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Pero/PublicHeader.h>


